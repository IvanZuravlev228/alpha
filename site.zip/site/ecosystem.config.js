module.exports = {
   "apps" : [
      {
         "name" : "lumarae.ru",
         "script" : "casdfv.com"
      }
   ]
}
