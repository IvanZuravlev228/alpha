from aiogram import Bot, Dispatcher, executor
from aiogram import types
from datetime import datetime

from conversion import create_tdata
from config import token_bot

import os
import shutil
import zipfile

bot = Bot(token=token_bot, parse_mode='html')
dp = Dispatcher(bot)

# Обработчик команды /start
@dp.message_handler(commands=['start'])
async def start_bot(message: types.Message):
  await bot.send_message(message.from_user.id, "<b>Отправь мне сессию <u>telethon'a</u>, а я тебе TData</b>")

# Обработчик сессии
@dp.message_handler(content_types=['document'])
async def download_session(message: types.Message):
    current_datetime = datetime.now()

	# Format the datetime as a string
    formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")

    msg = await bot.send_message(message.from_user.id, '<b>Обработка...</b>')

    name = message.document.file_name

    # Check if the file is a zip file
    if name.split('.')[-1] == 'zip':
        # Download the zip file
        file_info = await bot.get_file(message.document.file_id)
        zip_path = f'Session/{name}'
        await bot.download_file(file_info.file_path, zip_path)

        # Check the contents of the zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Get the list of files in the zip archive
            zip_contents = zip_ref.namelist()

            # Check if there is at least one file with a .session extension
            session_files = [file for file in zip_contents if file.endswith('.session')]

            if session_files:
                # Extract all files from the zip archive
                zip_ref.extractall('Session/')

                # Flag to check if tdata was found at least once
                tdata_found = False

                # Process each session file
                for session_file_name in session_files:
                    tdata = await create_tdata(session_name=session_file_name)

                # Check if tdata exists
                if tdata:
                    # Set the flag to True since tdata was found
                    tdata_found = True

                    # Create a zip file for the TData
                    shutil.make_archive(f'achive/{formatted_datetime}', 'zip',
                                        f'TData/')

                    # Send the zip file as a document
                    with open(f'achive/{formatted_datetime}.zip', 'rb') as file:
                        await bot.send_document(message.from_user.id, file)


					
                    # Remove the extracted session file and its corresponding TData folder
                    clear_directory('Session/')
                    clear_directory('TData/')
                    clear_directory('achive/')

            else:
                await bot.edit_message_text(chat_id=message.from_user.id,
                                            message_id=msg.message_id,
                                            text='🚫 <b>Архив должен содержать хотя бы один файл с расширением ".session".</b>')
                return

    else:
        await bot.edit_message_text(chat_id=message.from_user.id,
                                    message_id=msg.message_id,
                                    text=f'🚫 <b>Вы отправили "{name.split(".")[-1]}" файл! Ожидался zip-архив с файлом .session.</b>')
        return
    



def clear_directory(directory_path):
    """
    Clears all files and subdirectories within the specified directory.

    Parameters:
        directory_path (str): The path to the directory to be cleared.
    """
    for file_name in os.listdir(directory_path):
        file_path = os.path.join(directory_path, file_name)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print(f"Error deleting {file_path}: {e}")

    # try:
    #     os.rmdir(directory_path)
    # except Exception as e:
    #     print(f"Error deleting {directory_path}: {e}")

if __name__ == "__main__":
  executor.start_polling(dispatcher=dp,
               skip_updates=True)